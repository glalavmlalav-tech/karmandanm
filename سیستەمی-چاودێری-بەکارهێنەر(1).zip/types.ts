export type UserRole = 'admin' | 'user';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  password: string;
}

export type CaptureType = 'start' | 'end';

export interface Capture {
  id: string;
  userId: string;
  userName: string;
  image: string; // base64 data URL
  timestamp: Date;
  captureType: CaptureType;
}
