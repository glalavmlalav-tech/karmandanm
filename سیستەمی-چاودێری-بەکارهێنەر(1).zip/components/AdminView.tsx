import React, { useState, useMemo, useEffect } from 'react';
import { Capture, User } from '../types';

interface AdminViewProps {
  captures: Capture[];
  users: User[];
  onLogout: () => void;
  onAddUser: (userData: Pick<User, 'name'>) => void;
  onUpdateUser: (user: User) => void;
  onDeleteUser: (userId: string) => void;
}

const CAPTURES_PER_PAGE = 8;

const AdminView: React.FC<AdminViewProps> = ({ captures, users, onLogout, onAddUser, onUpdateUser, onDeleteUser }) => {
  const [activeTab, setActiveTab] = useState<'archive' | 'users'>('archive');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userName, setUserName] = useState('');
  const [userPassword, setUserPassword] = useState('');

  // State for filtering and searching
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [viewingCapture, setViewingCapture] = useState<Capture | null>(null);


  const filteredCaptures = useMemo(() => {
    return captures
      .filter(capture =>
        capture.userName.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .filter(capture => {
        const captureTimestamp = capture.timestamp.getTime();
        if (startDate) {
          const startTimestamp = new Date(startDate).getTime();
          if (captureTimestamp < startTimestamp) return false;
        }
        if (endDate) {
          const end = new Date(endDate);
          end.setHours(23, 59, 59, 999);
          const endTimestamp = end.getTime();
          if (captureTimestamp > endTimestamp) return false;
        }
        return true;
      });
  }, [captures, searchTerm, startDate, endDate]);
  
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, startDate, endDate]);

  const totalPages = Math.ceil(filteredCaptures.length / CAPTURES_PER_PAGE);
  const paginatedCaptures = filteredCaptures.slice(
    (currentPage - 1) * CAPTURES_PER_PAGE,
    currentPage * CAPTURES_PER_PAGE
  );

  const handleClearFilters = () => {
    setSearchTerm('');
    setStartDate('');
    setEndDate('');
    setCurrentPage(1);
  };

  const handleExportCSV = () => {
    if (filteredCaptures.length === 0) {
      alert('هیچ داتایەک نییە بۆ هەناردەکردن.');
      return;
    }
  
    const headers = ['User Name', 'User ID', 'Date', 'Time', 'Capture Type'];
    const rows = filteredCaptures.map(capture => [
      `"${capture.userName.replace(/"/g, '""')}"`, // Handle quotes in names
      capture.userId,
      capture.timestamp.toLocaleDateString('en-CA'), // YYYY-MM-DD for better sorting
      capture.timestamp.toLocaleTimeString('en-GB'), // HH:MM:SS
      capture.captureType === 'start' ? 'Start Work' : 'End Work'
    ]);
  
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');
  
    const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'captures_export.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  const openAddModal = () => {
    setEditingUser(null);
    setUserName('');
    setUserPassword('');
    setIsModalOpen(true);
  };

  const openEditModal = (user: User) => {
    setEditingUser(user);
    setUserName(user.name);
    setUserPassword('');
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingUser(null);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName) {
      alert("تکایە ناوێک بنووسە.");
      return;
    }
    if (editingUser) {
      onUpdateUser({ ...editingUser, name: userName, password: userPassword || editingUser.password });
    } else {
      onAddUser({ name: userName });
    }
    closeModal();
  };

  const handleDeleteClick = (userId: string) => {
    if (window.confirm('ئایا دڵنیایت لە سڕینەوەی ئەم بەکارهێنەرە؟')) {
      onDeleteUser(userId);
    }
  };
  
  const renderArchive = () => (
    <>
      <div className="bg-[#3B5260] p-4 rounded-lg shadow-md mb-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
              <div className="md:col-span-2">
                  <label htmlFor="search" className="block text-sm font-medium text-[#C1C8CF] mb-1">گەڕان بەدوای بەکارهێنەر</label>
                  <input
                      type="text"
                      id="search"
                      placeholder="ناوی بەکارهێنەر بنووسە..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full bg-[#2A3F4A] border border-[#5E8A9E] rounded-md py-2 px-3 text-[#F6E8D8] focus:ring-2 focus:ring-[#C98A5E]"
                  />
              </div>
              <div>
                  <label htmlFor="start-date" className="block text-sm font-medium text-[#C1C8CF] mb-1">بەرواری دەستپێک</label>
                  <input
                      type="date"
                      id="start-date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full bg-[#2A3F4A] border border-[#5E8A9E] rounded-md py-2 px-3 text-[#F6E8D8] focus:ring-2 focus:ring-[#C98A5E]"
                  />
              </div>
              <div>
                  <label htmlFor="end-date" className="block text-sm font-medium text-[#C1C8CF] mb-1">بەرواری کۆتایی</label>
                  <input
                      type="date"
                      id="end-date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full bg-[#2A3F4A] border border-[#5E8A9E] rounded-md py-2 px-3 text-[#F6E8D8] focus:ring-2 focus:ring-[#C98A5E]"
                  />
              </div>
               <div className="flex flex-col sm:flex-row md:flex-col gap-2">
                 <button onClick={handleExportCSV} className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-3 rounded-md transition duration-300 flex items-center justify-center gap-2 text-sm">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clipRule="evenodd" /></svg>
                    <span>CSV</span>
                </button>
                <button onClick={handleClearFilters} className="w-full bg-[#5E8A9E] hover:bg-[#4d7285] text-white font-bold py-2 px-3 rounded-md transition duration-300 text-sm">
                  سڕینەوەی فلتەر
                </button>
              </div>
          </div>
      </div>

      {paginatedCaptures.length === 0 ? (
        <div className="text-center text-[#C1C8CF] py-20 text-xl">
          هیچ وێنەیەک نەدۆزرایەوە.
        </div>
      ) : (
        <>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {paginatedCaptures.map(capture => (
            <div 
              key={capture.id} 
              onClick={() => setViewingCapture(capture)} 
              className={`bg-[#3B5260] rounded-lg shadow-lg overflow-hidden group transform transition-transform duration-300 hover:scale-105 cursor-pointer border-4 ${
                capture.captureType === 'start' ? 'border-green-500' : 'border-red-500'
              }`}
            >
              <img src={capture.image} alt={`Capture by ${capture.userName}`} className="w-full h-48 object-cover" />
              <div className="p-4">
                <p className="font-bold text-lg text-[#C98A5E]">{capture.userName}</p>
                <p className="text-sm text-[#C1C8CF] mt-1">
                  {capture.timestamp.toLocaleDateString('en-GB')}
                </p>
                <p className="text-xs text-[#C1C8CF]">
                  {capture.timestamp.toLocaleTimeString()}
                </p>
                 <p className={`text-xs font-semibold mt-2 ${capture.captureType === 'start' ? 'text-green-400' : 'text-red-400'}`}>
                    {capture.captureType === 'start' ? 'دەسپیکی کارکردن' : 'کۆتایی کارکردن'}
                </p>
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-center items-center mt-8 space-x-4">
            <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="bg-[#C98A5E] hover:bg-[#b87b52] text-white font-bold py-2 px-4 rounded-md disabled:bg-[#5E8A9E] disabled:cursor-not-allowed"
            >
                پێشوو
            </button>
            <span className="text-lg">
                لاپەڕە {currentPage} لە {totalPages}
            </span>
            <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="bg-[#C98A5E] hover:bg-[#b87b52] text-white font-bold py-2 px-4 rounded-md disabled:bg-[#5E8A9E] disabled:cursor-not-allowed"
            >
                دواتر
            </button>
        </div>
        </>
      )}
    </>
  );

  const renderUserManagement = () => (
    <div>
      <div className="flex justify-end mb-4">
        <button onClick={openAddModal} className="bg-[#C98A5E] hover:bg-[#b87b52] text-white font-bold py-2 px-4 rounded-md transition duration-300">
          زیادکردنی بەکارهێنەری نوێ
        </button>
      </div>
      <div className="bg-[#3B5260] rounded-lg shadow-lg overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-[#2A3F4A]">
            <tr>
              <th className="p-4">ناسنامەی بەکارهێنەر</th>
              <th className="p-4">ناو</th>
              <th className="p-4">ڕۆڵ</th>
              <th className="p-4 text-right">کردارەکان</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id} className="border-b border-[#5E8A9E] last:border-b-0">
                <td className="p-4">{user.id}</td>
                <td className="p-4">{user.name}</td>
                <td className="p-4">{user.role}</td>
                <td className="p-4 text-right space-x-2">
                  <button onClick={() => openEditModal(user)} className="text-[#C98A5E] hover:text-[#b87b52]">دەستکاری</button>
                  {user.role !== 'admin' && (
                    <button onClick={() => handleDeleteClick(user.id)} className="text-red-500 hover:text-red-400">سڕینەوە</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="w-full">
      <header className="w-full flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-[#C98A5E]">داشبۆردی ئەدمین</h1>
        <button
          onClick={onLogout}
          className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md transition duration-300"
        >
          چوونەدەرەوە
        </button>
      </header>
      
      <div className="mb-6 border-b border-[#5E8A9E]">
        <nav className="-mb-px flex space-x-6">
          <button 
            onClick={() => setActiveTab('archive')} 
            className={`py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'archive' ? 'border-[#C98A5E] text-[#C98A5E]' : 'border-transparent text-[#C1C8CF] hover:text-[#F6E8D8] hover:border-[#C1C8CF]'}`}
          >
            ئەرشیف
          </button>
          <button 
            onClick={() => setActiveTab('users')} 
            className={`py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'users' ? 'border-[#C98A5E] text-[#C98A5E]' : 'border-transparent text-[#C1C8CF] hover:text-[#F6E8D8] hover:border-[#C1C8CF]'}`}
          >
            بەڕێوەبردنی بەکارهێنەران
          </button>
        </nav>
      </div>

      {activeTab === 'archive' && renderArchive()}
      {activeTab === 'users' && renderUserManagement()}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-[#3B5260] p-8 rounded-lg shadow-2xl w-full max-w-md">
            <h2 className="text-2xl font-bold text-[#C98A5E] mb-6">{editingUser ? 'دەستکاریکردنی بەکارهێنەر' : 'زیادکردنی بەکارهێنەری نوێ'}</h2>
            <form onSubmit={handleSaveUser}>
              <div className="mb-4">
                <label htmlFor="user-name" className="block text-sm font-medium text-[#C1C8CF] mb-2">ناو</label>
                <input
                  id="user-name"
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full bg-[#2A3F4A] border border-[#5E8A9E] rounded-md py-2 px-3 text-[#F6E8D8] focus:ring-2 focus:ring-[#C98A5E]"
                  required
                />
              </div>
              {editingUser && (
                <div className="mb-6">
                  <label htmlFor="user-password" className="block text-sm font-medium text-[#C1C8CF] mb-2">وشەی تێپەڕبوون</label>
                  <input
                    id="user-password"
                    type="password"
                    value={userPassword}
                    onChange={(e) => setUserPassword(e.target.value)}
                    className="w-full bg-[#2A3F4A] border border-[#5E8A9E] rounded-md py-2 px-3 text-[#F6E8D8] focus:ring-2 focus:ring-[#C98A5E]"
                    placeholder={'بۆ گۆڕین، وشەی نهێنی نوێ بنووسە'}
                  />
                </div>
              )}
              <div className="flex justify-end space-x-4">
                <button type="button" onClick={closeModal} className="bg-[#5E8A9E] hover:bg-[#4d7285] text-white font-bold py-2 px-4 rounded-md">
                  پاشگەزبوونەوە
                </button>
                <button type="submit" className="bg-[#C98A5E] hover:bg-[#b87b52] text-white font-bold py-2 px-4 rounded-md">
                  پاشەکەوتکردن
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {viewingCapture && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4"
          onClick={() => setViewingCapture(null)}
        >
          <div 
            className={`bg-[#2A3F4A] p-4 rounded-lg shadow-2xl w-full max-w-3xl relative border-4 ${
              viewingCapture.captureType === 'start' ? 'border-green-500' : 'border-red-500'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              onClick={() => setViewingCapture(null)}
              className="absolute -top-4 -right-4 bg-red-600 hover:bg-red-700 text-white font-bold rounded-full h-9 w-9 flex items-center justify-center text-xl z-10"
              aria-label="داخستن"
            >
              &times;
            </button>
            <img 
              src={viewingCapture.image} 
              alt={`Capture by ${viewingCapture.userName}`} 
              className="w-full h-auto object-contain max-h-[70vh] rounded-md" 
            />
            <div className="mt-4 text-center">
              <p className="font-bold text-xl text-[#C98A5E]">{viewingCapture.userName}</p>
              <p className="text-md text-[#C1C8CF] mt-1">
                {viewingCapture.timestamp.toLocaleString('en-US', {
                  year: 'numeric', month: 'long', day: 'numeric', 
                  hour: '2-digit', minute: '2-digit', second: '2-digit'
                })}
              </p>
              <p className={`text-lg font-semibold mt-2 ${viewingCapture.captureType === 'start' ? 'text-green-400' : 'text-red-400'}`}>
                    {viewingCapture.captureType === 'start' ? 'دەسپیکی کارکردن' : 'کۆتایی کارکردن'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
