import React, { useRef, useEffect, useState } from 'react';
import { User, Capture, CaptureType } from '../types';

interface UserViewProps {
  user: User;
  onCapture: (captureData: Omit<Capture, 'id'>) => void;
  onLogout: () => void;
}

const UserView: React.FC<UserViewProps> = ({ user, onCapture, onLogout }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [lastCapture, setLastCapture] = useState<string | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    const setupCamera = async () => {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          stream = await navigator.mediaDevices.getUserMedia({ video: true });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.onloadedmetadata = () => {
              setIsCameraReady(true);
            };
          }
        } else {
            setError("کامیرا لەسەر ئەم وێبگەڕە بەردەست نییە.");
        }
      } catch (err) {
        console.error("Error accessing camera:", err);
        setError("هەڵەیەک ڕوویدا لە کردنەوەی کامیرا. تکایە دڵنیابە لەوەی کە ڕێگەپێدانت داوە.");
      }
    };

    setupCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleCapture = (type: CaptureType) => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setLastCapture(dataUrl);

        onCapture({
          userId: user.id,
          userName: user.name,
          image: dataUrl,
          timestamp: new Date(),
          captureType: type,
        });
      }
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      <header className="w-full max-w-5xl flex justify-between items-center mb-6 p-4 bg-[#3B5260] rounded-lg shadow-md">
        <h1 className="text-2xl font-bold text-[#C98A5E]">بەخێربێیت, {user.name}</h1>
        <button
          onClick={onLogout}
          className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md transition duration-300"
        >
          چوونەدەرەوە
        </button>
      </header>

      <div className="w-full max-w-5xl bg-[#3B5260] p-4 rounded-lg shadow-lg">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
             {!isCameraReady && !error && <div className="absolute inset-0 flex items-center justify-center text-[#C1C8CF]">چاوەڕوانی کامێرا...</div>}
             {error && <div className="absolute inset-0 flex items-center justify-center text-red-400 p-4 text-center">{error}</div>}
          </div>
          
          <div className="flex flex-col items-center justify-between">
            <div className="w-full aspect-video bg-[#2A3F4A] rounded-lg flex items-center justify-center overflow-hidden mb-4">
              {lastCapture ? (
                <img src={lastCapture} alt="Last capture" className="w-full h-full object-cover" />
              ) : (
                <div className="text-[#C1C8CF]">پێشبینی وێنەی گیراو</div>
              )}
            </div>
            <div className="w-full grid grid-cols-2 gap-4">
               <button
                onClick={() => handleCapture('start')}
                disabled={!isCameraReady}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-md transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-lg"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                دەسپیکی کارکردن
              </button>
              <button
                onClick={() => handleCapture('end')}
                disabled={!isCameraReady}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-md transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-lg"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" /></svg>
                کۆتایی کارکردن
              </button>
            </div>
          </div>
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden"></canvas>
    </div>
  );
};

export default UserView;
