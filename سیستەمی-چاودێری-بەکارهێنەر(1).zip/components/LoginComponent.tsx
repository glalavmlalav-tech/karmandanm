import React, { useState } from 'react';
import { User } from '../types';

interface LoginComponentProps {
  onLogin: (id: string, password?: string) => void;
  users: User[];
}

const LoginComponent: React.FC<LoginComponentProps> = ({ onLogin, users }) => {
  const [userId, setUserId] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId) {
      setError('تکایە بەکارهێنەرێک هەڵبژێرە.');
      return;
    }
    if (!password) {
        setError('تکایە وشەی نهێنی بنووسە.');
        return;
    }
    setError('');
    onLogin(userId, password);
  };


  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="bg-[#3B5260] p-8 rounded-lg shadow-2xl w-full max-w-md">
        <h1 className="text-3xl font-bold text-center text-[#C98A5E] mb-6">سیستەمی چاودێری</h1>
        <form onSubmit={handleLogin}>
          <div className="mb-4">
            <label htmlFor="user-id" className="block text-sm font-medium text-[#C1C8CF] mb-2">ناسنامەی بەکارهێنەر</label>
            <select
              id="user-id"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              className="w-full bg-[#2A3F4A] border border-[#5E8A9E] rounded-md py-3 px-4 text-[#F6E8D8] focus:ring-2 focus:ring-[#C98A5E] focus:outline-none"
              autoComplete="username"
            >
              <option value="" disabled>بەکارهێنەرێک هەڵبژێرە</option>
              {users.map(user => (
                <option key={user.id} value={user.id}>
                  {user.name} ({user.id})
                </option>
              ))}
            </select>
          </div>
          <div className="mb-6">
            <label htmlFor="password" className="block text-sm font-medium text-[#C1C8CF] mb-2">وشەی تێپەڕبوون</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#2A3F4A] border border-[#5E8A9E] rounded-md py-3 px-4 text-[#F6E8D8] focus:ring-2 focus:ring-[#C98A5E] focus:outline-none"
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </div>
          {error && <p className="text-red-400 text-sm text-center mb-4">{error}</p>}
          <button
            type="submit"
            className="w-full bg-[#C98A5E] hover:bg-[#b87b52] text-white font-bold py-3 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105"
          >
            چوونەژوورەوە
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginComponent;