import { useState, useEffect, useRef, useCallback } from 'react';

// دروستکردنی ناسنامەیەکی تاک بۆ هەر تابێک بۆ ئەوەی پەیامەکانی خۆی پشتگوێ بخات
const sourceId = Math.random().toString(36).substring(2);

type BroadcastMessage<T> = {
  sourceId: string;
  payload: T;
};

/**
 * A custom React hook that synchronizes state across multiple browser tabs/windows
 * using the BroadcastChannel API. It mimics the `useState` hook signature.
 * @param channelName A unique name for the broadcast channel.
 * @param initialState The initial state value.
 * @returns A stateful value, and a function to update it.
 */
export function useSharedState<T>(channelName: string, initialState: T): [T, (value: T | ((prevState: T) => T)) => void] {
  const [state, setState] = useState<T>(initialState);
  const channel = useRef<BroadcastChannel | null>(null);

  useEffect(() => {
    // دڵنیابوونەوە لەوەی وێبگەڕ پشتگیری BroadcastChannel دەکات
    if ('BroadcastChannel' in window) {
      channel.current = new BroadcastChannel(channelName);

      const handleMessage = (event: MessageEvent<BroadcastMessage<T>>) => {
        // پەیامەکە پشتگوێ دەخرێت ئەگەر لە هەمان تابەوە هاتبێت
        if (event.data && event.data.sourceId !== sourceId) {
          setState(event.data.payload);
        }
      };

      channel.current.addEventListener('message', handleMessage);

      // پاککردنەوەی کەناڵەکە کاتێک کۆمۆنێنتەکە لادەبرێت
      return () => {
        if (channel.current) {
          channel.current.removeEventListener('message', handleMessage);
          channel.current.close();
          channel.current = null;
        }
      };
    } else {
      console.warn('BroadcastChannel is not supported in this browser. State will not be synced across tabs.');
    }
  }, [channelName]);

  const setSharedState = useCallback((value: T | ((prevState: T) => T)) => {
    // بەکارهێنانی شێوازی فەنکشنی setState بۆ دڵنیابوونەوە لەوەی نوێترین ستەیت بەکاردەهێنرێت
    setState(prevState => {
      const newState = typeof value === 'function'
        ? (value as (prevState: T) => T)(prevState)
        : value;

      // دوای حیسابکردنی ستەیتی نوێ، پەخشی دەکەین بۆ تابەکانی تر
      if (channel.current) {
        const message: BroadcastMessage<T> = { sourceId, payload: newState };
        channel.current.postMessage(message);
      }
      
      return newState;
    });
  }, []); // හිස් array بۆ ئەوەی فەنکشنەکە تەنها یەکجار دروست بکرێت

  return [state, setSharedState];
}
