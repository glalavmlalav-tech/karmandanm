import { User } from './types';

export const INITIAL_USERS: User[] = [
  { id: 'admin', name: 'ئەدمین', role: 'admin', password: 'admin' },
  ...Array.from({ length: 10 }, (_, i) => ({
    id: `user${i + 1}`,
    name: `بەکارهێنەر ${i + 1}`,
    role: 'user' as const,
    password: '199525',
  })),
];
