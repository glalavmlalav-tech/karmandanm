import React, { useState } from 'react';
import { User, Capture } from './types';
import { INITIAL_USERS } from './constants';
import LoginComponent from './components/LoginComponent';
import UserView from './components/UserView';
import AdminView from './components/AdminView';
import { useSharedState } from './hooks/useSharedState';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [captures, setCaptures] = useSharedState<Capture[]>('captures-channel', []);
  const [users, setUsers] = useSharedState<User[]>('users-channel', INITIAL_USERS);

  const handleLogin = (id: string, password?: string) => {
    const user = users.find(u => u.id === id && u.password === password);
    if (user) {
      setCurrentUser(user);
    } else {
      alert('ناسنامەی بەکارهێنەر یان وشەی تێپەڕبوون هەڵەیە');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleAddCapture = (newCaptureData: Omit<Capture, 'id'>) => {
    const newCapture: Capture = {
      ...newCaptureData,
      id: `capture-${Date.now()}-${Math.random()}`,
    };
    setCaptures(prevCaptures => [newCapture, ...prevCaptures]);
  };

  const handleAddUser = (userData: Pick<User, 'name'>) => {
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: userData.name,
      password: '199525',
      role: 'user',
    };
    setUsers(prevUsers => [...prevUsers, newUser]);
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUsers(prevUsers => prevUsers.map(user => user.id === updatedUser.id ? updatedUser : user));
  };
  
  const handleDeleteUser = (userId: string) => {
    if (userId === 'admin') {
        alert("ناتوانیت ئەکاونتی ئەدمین بسڕیتەوە.");
        return;
    }
    setUsers(prevUsers => prevUsers.filter(user => user.id !== userId));
  };


  const renderContent = () => {
    if (!currentUser) {
      return <LoginComponent users={users} onLogin={handleLogin} />;
    }

    if (currentUser.role === 'admin') {
      return <AdminView 
        captures={captures} 
        users={users}
        onLogout={handleLogout}
        onAddUser={handleAddUser}
        onUpdateUser={handleUpdateUser}
        onDeleteUser={handleDeleteUser}
      />;
    }

    if (currentUser.role === 'user') {
      return <UserView user={currentUser} onCapture={handleAddCapture} onLogout={handleLogout} />;
    }

    return null;
  };

  return (
    <div className="min-h-screen bg-[#2A3F4A] text-[#F6E8D8] flex flex-col items-center justify-center p-4">
      <main className="w-full max-w-7xl">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;
